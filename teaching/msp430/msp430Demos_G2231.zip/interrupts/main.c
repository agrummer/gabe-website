/**
 * @file main.c
 * Interrupt Demo
 * MSP430 LaunchPad - MSP430G2231
 *
 * This code simply blinks the green LED (LED2) continuously in a loop using a
 * timer interrupt, and the red LED (LED1) is toggled everytime the user presses
 * the botton SW2. LED1 is toggled after receiving the interrupt that the button
 * was pressed. When not in an interrupt routine, the processor is in an
 * ultra-low-power mode.
 *
 * @author Gabe Cohn
 * @date 01/31/2012 - Gabe Cohn     @li initial revision
 ******************************************************************************/

#include "msp430.h"                     /* include MSP430 definitions */


/* **** definitions **** */
#define LED2_BLINK_PERIOD 0x7FFF        /* timer cycles between LED2 toggles */

/* pinout */
#define LED1            BIT0            /* LED1 is on P1.0 */
#define LED2            BIT6            /* LED2 is on P1.6 */
#define SW2             BIT3            /* SW2 in on P1.3 */


/* **** local function prototypes **** */
__interrupt void P1_ISR(void);
__interrupt void TA0_ISR(void);


/** mainloop */
void main(void) {
   
    /* *************************************************************************
     * initialize system
     **************************************************************************/

    /* disable global interrupts during initialization */
    __disable_interrupt();

    /* disable WDT so that the processor does not reset */
    WDTCTL = WDTPW | WDTHOLD;

    /* *************************************************************************
     * configure pins
     **************************************************************************/
        
    /* configure all pins as digital inputs with pull-downs (to save power) */
    
    /* PORT 1 */
    P1DIR = 0;                          /* set as inputs */
    P1SEL = 0;                          /* set as digital I/Os */
    P1OUT = 0;                          /* set resistors as pull-downs */
    P1REN = 0xFF;                       /* enable pull-down resistors */
    /* PORT 2 */
    P2DIR = 0;                          /* set as inputs */
    P2SEL = 0;                          /* set as digital I/Os */
    P2OUT = 0;                          /* set resistors as pull-downs */
    P2REN = 0xFF;                       /* enable pull-down resistors */

    
    /* now configure the pins that we will actually use */
    
    /* configure both LEDs as digital outputs */
    P1REN &= ~(LED1 | LED2);            /* disable pull-up/downs */
    P1DIR |= (LED1 | LED2);             /* configure as oututs */
    
    /* configure SW2 as a digital input */
    P1REN &= ~(SW2);                    /* disable pull-up/downs 
                                         * (there is a pull-up on the board) */
    P1IES |= SW2;                       /* trigger interrupt on falling edge */
    P1IE |= SW2;                        /* enable interrupts */
    
    
    /* *************************************************************************
     * configure timers
     **************************************************************************/
    
    /* configure Timer_A with the following parameters:
     *  - SMCLK/8 source
     *  - Up Mode (will count up to TACCR0 and then reset to 0)
     *  - generate interrupts when timer value == TACCR0
     */
    TACTL = TASSEL_2 | ID_3 | MC_1 | TACLR;
    TACCTL0 = CCIE;
    TACCR0 = LED2_BLINK_PERIOD - 1;     /* the true period is TACCR0 + 1 */
    
    /* *************************************************************************
     * enable global interrupts
     **************************************************************************/
    __enable_interrupt();

    
    /* *************************************************************************
     * run mainloop
     **************************************************************************/
    
    __low_power_mode_1();               /* enter LPM1 (turn off CPU) */
    
    /* the code should never get here since LPM1 will turn off the CPU, 
     * but just in case, just spin the CPU forever */
    __no_operation();                   /* just for setting breakpoints here */
    while (1);
}

/* interrupt service routine for PORT 1 inputs */
#pragma vector=PORT1_VECTOR
__interrupt void P1_ISR(void) {
    
    if (P1IFG & SW2) {              /* SW2 button was pressed */
        P1IFG &= ~SW2;              /* clear interrupt flag */
        P1OUT ^= LED1;              /* toggle LED1 */
    }
    return;
}

/* interrupt service routine for Timer_A CC0 */
#pragma vector=TIMERA0_VECTOR
__interrupt void TA0_ISR(void) {
    
    P1OUT ^= LED2;                  /* toggle LED2 */
    return;
}
