/**
 * @file main.c
 * PWM Demo
 * MSP430 LaunchPad - MSP430G2231
 *
 * This code uses pulse width modulation (PWM) to control the brightness of 
 * LED2. The LED slowly gets brighter and then dimmer in a loop.
 *
 * @author Gabe Cohn
 * @date 01/31/2012 - Gabe Cohn     @li initial revision
 ******************************************************************************/

#include "msp430.h"                     /* include MSP430 definitions */


/* **** definitions **** */
#define LED2_PWM_PERIOD     255         /* PWM period */
#define BRIGHT_CHG_PERIOD   9000        /* number of clocks between changes in
                                         * LED brightness */
#define BRIGHT_DELTA        1           /* amount to change brightness each step */

/* pinout */
#define LED2            BIT6            /* LED2 is on P1.6 */


/** mainloop */
void main(void) {
    
    unsigned short ledBrightness;       /* the current brightness of the LED */
    short delta;                        /* amount to change brightness each step */
    
    
    /* *************************************************************************
     * initialize system
     **************************************************************************/

    /* disable global interrupts - don't need interrupts on this project */
    __disable_interrupt();

    /* disable WDT so that the processor does not reset */
    WDTCTL = WDTPW | WDTHOLD;

    /* *************************************************************************
     * configure pins
     **************************************************************************/
        
    /* configure all pins as digital inputs with pull-downs (to save power) */
    
    /* PORT 1 */
    P1DIR = 0;                          /* set as inputs */
    P1SEL = 0;                          /* set as digital I/Os */
    P1OUT = 0;                          /* set resistors as pull-downs */
    P1REN = 0xFF;                       /* enable pull-down resistors */
    /* PORT 2 */
    P2DIR = 0;                          /* set as inputs */
    P2SEL = 0;                          /* set as digital I/Os */
    P2OUT = 0;                          /* set resistors as pull-downs */
    P2REN = 0xFF;                       /* enable pull-down resistors */

    
    /* now configure the pins that we will actually use */
    
    /* configure LED2 (P1.6) as Timer_A0 OUT1 (TA0.1) */
    P1REN &= ~(LED2);                   /* disable pull-up/downs */
    P1DIR |= LED2;
    P1SEL |= LED2;
    
    
    /* *************************************************************************
     * configure timers
     **************************************************************************/
    
    /* configure Timer_A to produce PWM output using the following parameters:
     *  - SMCLK/8 source
     *  - Up Mode (will count up to TACCR0 and then reset to 0)
     *  - OUT1 is set when timer value == TACCR0 and 
     *    reset when timer value == TACCR1
     *    Therefore:
     *      TACCR0 determines the PWM period
     *      TACCR1 determines the amount of on-time (large value => brighter)
     */
    TACTL = TASSEL_2 | ID_3 | MC_1 | TACLR;
    TACCTL1 = OUTMOD_7;
    TACCR0 = LED2_PWM_PERIOD - 1;       /* the true period is TACCR0 + 1 */
    TACCR1 = 0;                         /* the initial PWM value */

    
    /* *************************************************************************
     * run mainloop
     **************************************************************************/
    
    ledBrightness = 1;
    delta = BRIGHT_DELTA;
    while (1) {                         /* mainloop never exits */
        /* change brightness directions at end of scale */
        if (ledBrightness >= LED2_PWM_PERIOD || ledBrightness == 0) {
            delta *= -1;                /* flip brightness change direction */
        }
        
        ledBrightness += delta;         /* change brightness setting */
        TACCR1 = ledBrightness;         /* set new brightness */
            
        /* wait before changing brightness again */
        __delay_cycles(BRIGHT_CHG_PERIOD);
    }
}
