/**
 * @file main.c
 * Hello World
 * MSP430 LaunchPad - MSP430G2231
 *
 * This code simply blinks an LED forever.
 *
 * @author Gabe Cohn
 * @date 01/31/2012 - Gabe Cohn     @li initial revision
 ******************************************************************************/

#include "msp430.h"                     /* include MSP430 definitions */


/* **** definitions **** */
#define LED_TOGGLE_CNT  0x7FFF          /* loop cycles between LED toggles */

/* pinout */
#define LED1            BIT0            /* LED1 is on P1.0 */


/** mainloop */
void main(void) {
   
    unsigned int cnt;                   /* counter variable */


    /* initialize system */
    WDTCTL = WDTPW | WDTHOLD;           /* disable WDT */
    
    /* configure LED1 as a digital output */
    P1REN &= ~LED1;                     /* disable pull-up/down */
    P1DIR |= LED1;                      /* configure as output */
    

    /* run mainloop */
    cnt = 0;
    while (1) {                         /* mainloop should never return */
        if (cnt++ == LED_TOGGLE_CNT) {
            cnt = 0;
            P1OUT ^= LED1;              /* toggle LED1 */
        }
    }
}
